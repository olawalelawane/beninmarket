import Link from "next/link"
import { notFound } from "next/navigation"
import { ArrowLeft, Check, ShoppingCart, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { featuredProducts } from "@/lib/data"

interface ProductPageProps {
  params: {
    id: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const product = featuredProducts.find((p) => p.id === params.id)

  if (!product) {
    notFound()
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Link href="/products" className="inline-flex items-center text-sm font-medium hover:underline mb-6">
        <ArrowLeft className="mr-1 h-4 w-4" />
        Back to Products
      </Link>
      <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
        <div className="flex flex-col gap-4">
          <div className="overflow-hidden rounded-lg border bg-background">
            <img
              src={product.image || "/placeholder.svg?height=600&width=600"}
              alt={product.name}
              className="aspect-square object-cover"
              width={600}
              height={600}
            />
          </div>
          <div className="grid grid-cols-4 gap-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="overflow-hidden rounded-lg border bg-background">
                <img
                  src={product.image || `/placeholder.svg?height=150&width=150&text=${i}`}
                  alt={`${product.name} thumbnail ${i}`}
                  className="aspect-square object-cover"
                  width={150}
                  height={150}
                />
              </div>
            ))}
          </div>
        </div>
        <div className="flex flex-col gap-4">
          <div>
            <h1 className="text-3xl font-bold">{product.name}</h1>
            <div className="mt-2 flex items-center gap-2">
              <div className="flex">
                {Array(5)
                  .fill(0)
                  .map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(product.rating)
                          ? "fill-yellow-400 text-yellow-400"
                          : "fill-gray-200 text-gray-200"
                      }`}
                    />
                  ))}
              </div>
              <span className="text-sm text-muted-foreground">({product.reviewCount} reviews)</span>
            </div>
            <div className="mt-4 flex items-center gap-2">
              <div className="text-3xl font-bold">${product.price.toFixed(2)}</div>
              {product.isVerifiedSeller && (
                <div className="inline-flex items-center rounded-full border border-green-500 bg-green-50 px-2.5 py-0.5 text-xs font-semibold text-green-700 dark:bg-green-900/20 dark:text-green-400">
                  <Check className="mr-1 h-3 w-3" />
                  Verified Seller
                </div>
              )}
            </div>
            <div className="mt-4 text-muted-foreground">
              <p>Seller: {product.seller}</p>
              <p>Category: {product.category}</p>
              <p>In Stock: {product.stock} items</p>
            </div>
          </div>
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="details">Details</TabsTrigger>
            </TabsList>
            <TabsContent value="description" className="py-4">
              <p>{product.description}</p>
            </TabsContent>
            <TabsContent value="details" className="py-4">
              <ul className="list-inside list-disc space-y-2">
                <li>Handcrafted by skilled artisans</li>
                <li>Made with sustainable materials</li>
                <li>Unique design</li>
                <li>Durable and long-lasting</li>
              </ul>
            </TabsContent>
          </Tabs>
          <div className="flex flex-col gap-2 sm:flex-row">
            <div className="flex items-center">
              <Button variant="outline" size="icon" className="rounded-r-none" disabled={product.stock === 0}>
                -
              </Button>
              <div className="flex h-10 w-14 items-center justify-center border-y">1</div>
              <Button variant="outline" size="icon" className="rounded-l-none" disabled={product.stock === 0}>
                +
              </Button>
            </div>
            <Button className="flex-1" size="lg" disabled={product.stock === 0}>
              <ShoppingCart className="mr-2 h-5 w-5" />
              Add to Cart
            </Button>
          </div>
          <div className="rounded-lg border p-4">
            <h3 className="font-medium">Delivery Information</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Free shipping on orders over $100. Delivery typically takes 3-5 business days. Escrow payment ensures your
              money is safe until you confirm receipt.
            </p>
          </div>
        </div>
      </div>
      <div className="mt-12">
        <h2 className="text-2xl font-bold">Customer Reviews</h2>
        <div className="mt-6 grid gap-6">
          {Array(3)
            .fill(0)
            .map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <CardTitle className="text-lg">Great product!</CardTitle>
                  <CardDescription>
                    <div className="flex items-center gap-2">
                      <div className="flex">
                        {Array(5)
                          .fill(0)
                          .map((_, j) => (
                            <Star
                              key={j}
                              className={`h-4 w-4 ${
                                j < 4 + (i % 2) ? "fill-yellow-400 text-yellow-400" : "fill-gray-200 text-gray-200"
                              }`}
                            />
                          ))}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {new Date(Date.now() - 1000 * 60 * 60 * 24 * (i + 1)).toLocaleDateString()}
                      </span>
                    </div>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm">
                    {
                      [
                        "I absolutely love this product! The quality is exceptional and it arrived quickly.",
                        "This exceeded my expectations. The craftsmanship is outstanding.",
                        "Great value for money. I would definitely buy from this seller again.",
                      ][i]
                    }
                  </p>
                </CardContent>
                <CardFooter>
                  <p className="text-sm text-muted-foreground">By {["John D.", "Sarah M.", "Michael K."][i]}</p>
                </CardFooter>
              </Card>
            ))}
        </div>
      </div>
    </div>
  )
}

