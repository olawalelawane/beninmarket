import { Suspense } from "react"
import Link from "next/link"
import { Filter, SlidersHorizontal } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import ProductCard from "@/components/product-card"
import { featuredProducts, categories } from "@/lib/data"

export default function ProductsPage() {
  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Products</h1>
          <p className="text-muted-foreground">Browse and discover amazing products from our marketplace.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="hidden md:flex">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm" className="md:hidden">
            <SlidersHorizontal className="mr-2 h-4 w-4" />
            Filters
          </Button>
          <Select defaultValue="featured">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="featured">Featured</SelectItem>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        <div className="hidden md:block space-y-4">
          <div className="rounded-lg border p-4">
            <h2 className="mb-2 font-semibold">Categories</h2>
            <div className="space-y-2">
              {categories.map((category) => (
                <Link key={category.id} href={`/category/${category.slug}`} className="block text-sm hover:underline">
                  {category.name}
                </Link>
              ))}
            </div>
          </div>
          <div className="rounded-lg border p-4">
            <h2 className="mb-2 font-semibold">Price Range</h2>
            <div className="space-y-4">
              <div className="flex items-center">
                <input type="checkbox" id="price-1" className="h-4 w-4 rounded border-gray-300" />
                <label htmlFor="price-1" className="ml-2 text-sm">
                  Under $50
                </label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="price-2" className="h-4 w-4 rounded border-gray-300" />
                <label htmlFor="price-2" className="ml-2 text-sm">
                  $50 - $100
                </label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="price-3" className="h-4 w-4 rounded border-gray-300" />
                <label htmlFor="price-3" className="ml-2 text-sm">
                  $100 - $200
                </label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="price-4" className="h-4 w-4 rounded border-gray-300" />
                <label htmlFor="price-4" className="ml-2 text-sm">
                  $200+
                </label>
              </div>
            </div>
          </div>
          <div className="rounded-lg border p-4">
            <h2 className="mb-2 font-semibold">Seller Type</h2>
            <div className="space-y-2">
              <div className="flex items-center">
                <input type="checkbox" id="verified" className="h-4 w-4 rounded border-gray-300" />
                <label htmlFor="verified" className="ml-2 text-sm">
                  Verified Sellers Only
                </label>
              </div>
            </div>
          </div>
        </div>
        <div className="col-span-1 md:col-span-2 lg:col-span-3">
          <Suspense fallback={<ProductsLoading />}>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </Suspense>
        </div>
      </div>
    </div>
  )
}

function ProductsLoading() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {Array(6)
        .fill(0)
        .map((_, i) => (
          <div key={i} className="rounded-lg border">
            <Skeleton className="aspect-square rounded-t-lg" />
            <div className="p-4 space-y-2">
              <Skeleton className="h-4 w-2/3" />
              <Skeleton className="h-4 w-1/2" />
              <div className="flex justify-between pt-2">
                <Skeleton className="h-4 w-1/4" />
                <Skeleton className="h-4 w-1/4" />
              </div>
            </div>
          </div>
        ))}
    </div>
  )
}

