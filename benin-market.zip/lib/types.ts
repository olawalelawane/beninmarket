export interface Product {
  id: string
  name: string
  description: string
  price: number
  image?: string
  category: string
  seller: string
  isVerifiedSeller: boolean
  rating: number
  reviewCount: number
  stock: number
}

export interface Category {
  id: string
  name: string
  slug: string
  image?: string
}

export interface User {
  id: string
  name: string
  email: string
  isVerifiedSeller: boolean
  createdAt: Date
}

export interface Order {
  id: string
  userId: string
  products: {
    productId: string
    quantity: number
    price: number
  }[]
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled"
  total: number
  createdAt: Date
}

export interface Review {
  id: string
  userId: string
  productId: string
  rating: number
  comment: string
  createdAt: Date
}

